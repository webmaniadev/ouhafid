This is a technical glue module to make 'Project timesheet time control' and 'Sales Timesheet' work together.
It doesn't bring any feature by itself.
It does not count invoiced timesheet lines as running timers.
Only completed timesheet lines will be invoiced. (Running timers will not be invoiced until stopped).
