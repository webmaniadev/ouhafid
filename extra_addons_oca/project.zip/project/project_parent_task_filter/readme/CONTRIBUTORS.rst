* `C2i Change 2 improve <http://c2i.es/>`_:

  * Eduardo Magdalena <emagdalena@c2i.es>

* Stephan Keller <MiStK@gmx.de>

* `Ooops <http://ooops404.com/>`_:

  * Ashish Hirpara <ashish.hirapara1995@gmail.com>
