This module is not needed in v15 because odoo core has already added the messaging in project.
