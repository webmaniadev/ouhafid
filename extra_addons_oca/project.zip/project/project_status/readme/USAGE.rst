To use this module, you need to:

#. Have Manager rights for Project group to create project statuses.
#. Go to *Project > Configuration > Project Statuses*.
#. When creating a project or editing it, select the status
