To use this module, you need to:

#. Go to `Project / Configuration / GTD / Timeboxes` to configure your timeboxes.
#. Here, your new timebox is empty and not visible yet. You need to add tasks in it to make it visible.
#. Go to `Project / Tasks` and edit a task to set the 'Timeframe' field.
#. Now go to `Project / Tasks (GTD)` to drag and drop your tasks between timeboxes.
