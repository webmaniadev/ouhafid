* OpenERP SA
* Sébastien ALIX <sebastien.alix@osiell.com>
* Matthieu MÉQUIGNON <matthieu.mequignon@osiell.com>
* Alfredo Zamora <alfredo.zamora@agilebg.com>
