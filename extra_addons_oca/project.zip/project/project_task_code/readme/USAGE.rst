To use this module, you need to:

#. Go to menu Project > Search > Tasks and create a new task, and you get a
new code saving it.
#. If you duplicate a task, you will get a new code for the new task.
