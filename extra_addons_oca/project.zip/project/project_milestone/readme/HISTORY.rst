14.0.1.0.0
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

* Initial release


14.0.1.1.0
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

* New features added
    #. Subtask inherit the milestones from parent task
    #. 'Milestone Required' field is added on project
    #. Milestone can be assigned directly from Task Kanban
