* Patrick Wilson <patrickraymondwilson@gmail.com>
* `Ooops <https://www.ooops404.com>`_:

  * Ashish Hirpara
