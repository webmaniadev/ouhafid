Allows to assign and create stages when creating a project. Stages are visible on project views.
