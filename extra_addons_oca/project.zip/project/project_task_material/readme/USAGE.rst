To use this module:

Every task form has a tab where product and their quantities can be added.
