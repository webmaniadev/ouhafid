To use this module, you need to:

#. Open a task or create a new one
#. On the priority widget, three stars are displayed (instead of one)
#. Click on the second star: the priority of this task is now set to `High`
#. Click on the third star: the priority of this task is now set to `Very High`
