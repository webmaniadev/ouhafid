This module adds the function to copy milestones when creating projects from templates.
