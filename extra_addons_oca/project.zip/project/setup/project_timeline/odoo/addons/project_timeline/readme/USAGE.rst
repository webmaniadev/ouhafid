To view the timeline:

* Go to *Project > Search > Tasks* or *Project > Dashboard*.
* Click on the timeline view icon.
* You will see the tasks or projects in the new view.

The Task timeline uses the Start Date and End Date fields, in the Extra Info tab.
