By installing this module, the project field
will be mandatory for all the companies.

To make project selection optional on task for a given company:

# Go to *Project > Configuration > Settings*
# Uncheck *Require Projects on Tasks*
