This module allows to configure task as having project as a mandatory field.
