This module is an addition to the module Project Timeline.
It adds the progress of tasks (hr_timesheet) on the timeline view.
