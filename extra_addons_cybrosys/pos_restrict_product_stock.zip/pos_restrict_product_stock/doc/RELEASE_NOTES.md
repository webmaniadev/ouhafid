## Module <pos_restrict_product_stock>

#### 17.01.2024
#### Version 15.0.1.0.0
#### ADD
- Initial Commit for Display Stock in POS | Restrict Out-of-Stock Products in POS
