# -*- coding: utf-8 -*-
{
    'name': "Client In Move Line Product",
    'description': """
        Client In Move Line Product
    """,
    'author': "WEBMANIA",
    'website': "http://www.webmania.ma",

    'category': 'Stock',
    'version': '0.1',

    'depends': ['base', 'stock'],
    'data': [
        'views/view_stock_mive_line.xml',
    ],
}
