# -*- coding: utf-8 -*-
{
    'name': "Get reference of reserved qte ",
    'description': """
        Long  , run description of module's purpose
    """,
    'author': "webmania",
    'website': "http://www.webmania.ma",
    'category': 'Stock',
    'version': '0.1',
    'depends': ['base' , 'product'],
    'data': [
        'views/view_product_template.xml',
    ],
}
